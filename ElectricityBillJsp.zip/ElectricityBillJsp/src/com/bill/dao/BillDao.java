package com.bill.dao;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import javax.naming.InitialContext;
import javax.sql.DataSource;

import com.bill.bean.BillBean;
import com.bill.bean.ConsumerBean;

public class BillDao implements IBillDao{
	ArrayList al = new ArrayList();
	ConsumerBean consBean = new ConsumerBean();
	BillBean bean = new BillBean();
	@Override
	public ArrayList listOfConsumers() {
		
		try {
			
			InitialContext ic = new InitialContext();
			DataSource ds = (DataSource) ic.lookup("java:/OracleDS");
			Connection con = ds.getConnection();
			Statement st = con.createStatement();
			ResultSet rs= st.executeQuery("Select * from CONSUMERS");
			while(rs.next())
			{
				ConsumerBean bean = new ConsumerBean();
				bean.setConsumerNum(rs.getInt(1));
				bean.setConumserName(rs.getString(2));
				bean.setAddress(rs.getString(3));
				al.add(bean);
			}
			con.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return al; 
		
	}
	
	
	@Override
	public ArrayList getBillDetails(int ConsNum) {
		ArrayList al = new ArrayList();
		try {
			InitialContext ic = new InitialContext();
			DataSource ds = (DataSource) ic.lookup("java:/OracleDS");
			Connection con = ds.getConnection();
			Statement st = con.createStatement();
			ResultSet rs= st.executeQuery("Select * from BILLDETAILS where CONSUMER_NUM="+ConsNum);
			while(rs.next())
			{
				BillBean bean = new BillBean();
				bean.setBillnum(rs.getInt(1));
				bean.setConsumerNum(rs.getInt(2));
				bean.setCurrReadings(rs.getInt(3));
				bean.setUnitsConsumed(rs.getInt(4));
				bean.setNetAmount(rs.getInt(5));
				bean.setDate(rs.getDate(6));
				System.out.println(bean.getConsumerNum());
				al.add(bean);
				
			}
			con.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return al; 
		
	}


	@Override
	public ConsumerBean getConsumerDetails(int ConsNum) {
		try {
			InitialContext ic = new InitialContext();
			DataSource ds = (DataSource) ic.lookup("java:/OracleDS");
			Connection con = ds.getConnection();
			Statement st = con.createStatement();
			ResultSet rs= st.executeQuery("Select * from CONSUMERS where CONSUMER_NUM="+ConsNum);
			rs.next();
			System.out.println(rs.getInt(1));
			consBean.setConsumerNum(rs.getInt(1));
			consBean.setConumserName(rs.getString(2));
			consBean.setAddress(rs.getString(3));
			con.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return consBean;
			
	}


	@Override
	public int insertBillDetails(BillBean bean) {
		int result = 0;
		try {
			InitialContext ic = new InitialContext();
			DataSource ds = (DataSource) ic.lookup("java:/OracleDS");
			Connection con = ds.getConnection();
			con = ds.getConnection();
			
			PreparedStatement ps = con.prepareStatement("INSERT INTO BILLDETAILS VALUES(SEQ_BILL_NUM.NEXTVAL,?,?,?,?,SYSDATE)");
			
			ps.setInt(1, bean.getConsumerNum());
			ps.setDouble(2, bean.getCurrReadings());
			ps.setDouble(3, bean.getUnitsConsumed());
			ps.setDouble(4, bean.getNetAmount());
			
			result = ps.executeUpdate();
			if(result == 1)
				System.out.println("Data inserted");
			else
				System.out.println("Data not inserted");
			con.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
		
	}


	@Override
	public int ValidateConsNumber(int number) {
		int count = 0;
		try {
			InitialContext ic = new InitialContext();
			DataSource ds = (DataSource) ic.lookup("java:/OracleDS");
			Connection con = ds.getConnection();
			con = ds.getConnection();
			PreparedStatement ps = con.prepareStatement("select count(*) from CONSUMERS where CONSUMER_NUM = "+number);
			ResultSet rs  = ps.executeQuery();
			rs.next();
			System.out.println(rs.getInt(1));
			if(rs.getInt(1) < 1)
			{
				count = 0;
			}
			else{
				count = 1;
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return count;
	}
	
}
