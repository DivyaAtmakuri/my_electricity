package com.bill.pi;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import javax.naming.InitialContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import com.bill.bean.BillBean;
import com.bill.bean.ConsumerBean;
import com.bill.dao.BillDao;
import com.bill.service.BillService;

/**
 * Servlet implementation class EbillController
 */
@WebServlet("/EbillController")
public class EbillController extends HttpServlet {
	BillService service = new BillService();
	ConsumerBean consBean = new ConsumerBean();
	BillBean bean = new BillBean();
	ArrayList al;
    public EbillController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/* (non-Javadoc)
	 * @see javax.servlet.http.HttpServlet#doGet(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		BillBean bill = new BillBean();
		PrintWriter out = response.getWriter();
		
		
		
		
		//Getting Consumer Details based on the searched consumer number
		String SearchCons = request.getParameter("Number");
		if(request.getParameter("search") != null) {
			if(request.getParameter("search").equals("search"))
			{
				consBean = service.getConsumerDetails(Integer.parseInt(SearchCons));
				request.setAttribute("Arraylist", consBean);
				System.out.println(consBean.getConsumerNum());
				request.getRequestDispatcher("/showConsumer.jsp").forward(request, response);
			}
		}
		
		
		
		
		
		
		
		
		
		//Getting bill Details of a particular ConsumerNumber
		//String operation = request.getParameter("operation");

		if(request.getParameter("operation") != null){
			int ConsNumber = Integer.parseInt(request.getParameter("ConsumerNum"));
			if(request.getParameter("operation").equals("billDetails")){
				al = service.getBillDetails(ConsNumber);
				request.setAttribute("Details", al);
				request.setAttribute("ConsNum", ConsNumber);
				request.getRequestDispatcher("/showBills.jsp").forward(request, response);
			}
		}
	
		
		if(request.getParameter("CalculateBill")!=null)
		{
			if(request.getParameter("CalculateBill").equals("Calculate Bill")){
				double fixedCharge = 100.0;
				double netAmount = 0.00;
				int ConsNum = Integer.parseInt(request.getParameter("number"));
				if(service.ValidateConsNumber(ConsNum) == 1){
					double lastMonth = Double.parseDouble(request.getParameter("lastMonth"));
					double currentMonth = Double.parseDouble(request.getParameter("currentMonth"));
					double unitsConsumed = Math.abs(lastMonth - currentMonth);
					netAmount = unitsConsumed * 1.15 + fixedCharge;
					bean.setConsumerNum(ConsNum);
					bean.setCurrReadings(currentMonth);
					bean.setUnitsConsumed(unitsConsumed);
					bean.setNetAmount(netAmount);
					System.out.println(bean.getNetAmount());
					service.insertBillDetails(bean);
					request.setAttribute("Billbean", bean);
					request.getRequestDispatcher("/BillInfo.jsp").forward(request, response);
				}
				else{
					request.getRequestDispatcher("/Error.jsp").forward(request, response);
				}
			}
		}
		
		//Getting ConsumerList
		else{
			al = service.listOfConsumers();
			request.setAttribute("Array", al);
			request.getRequestDispatcher("/ConsumerList.jsp").forward(request, response);
		}
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
