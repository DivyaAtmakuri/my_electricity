package com.bill.service;

import java.util.ArrayList;

import com.bill.bean.BillBean;
import com.bill.bean.ConsumerBean;

public interface IBillService {
	public abstract ArrayList listOfConsumers();
	public abstract ArrayList getBillDetails(int ConsNum);
	public abstract ConsumerBean getConsumerDetails(int ConsNum);
	public abstract int ValidateConsNumber(int number);
	 public abstract int insertBillDetails(BillBean bean);
}
