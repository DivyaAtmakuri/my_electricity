package com.bill.service;

import java.util.ArrayList;

import com.bill.bean.BillBean;
import com.bill.bean.ConsumerBean;
import com.bill.dao.BillDao;
import com.bill.dao.IBillDao;

public class BillService implements IBillService{

	@Override
	public ArrayList listOfConsumers() {
		IBillDao dao = new BillDao();
		return dao.listOfConsumers();
	}

	@Override
	public ArrayList getBillDetails(int ConsNum) {
		IBillDao dao = new BillDao();
		return dao.getBillDetails(ConsNum);
	}

	@Override
	public ConsumerBean getConsumerDetails(int ConsNum) {
		IBillDao dao = new BillDao();
		return dao.getConsumerDetails(ConsNum);
		
	}

	@Override
	public int insertBillDetails(BillBean bean) {
		IBillDao dao = new BillDao();
		return dao.insertBillDetails(bean);
		
	}

	@Override
	public int ValidateConsNumber(int number) {
		IBillDao dao = new BillDao();
		return dao.ValidateConsNumber(number);
	}

	
	

}
