package com.bill.bean;

import java.sql.Date;
public class BillBean {
	private int billnum;
	private int consumerNum;
	private double currReadings;
	private double unitsConsumed;
	private double netAmount;
	private Date date;
	public int getBillnum() {
		return billnum;
	}
	public void setBillnum(int billnum) {
		this.billnum = billnum;
	}
	public int getConsumerNum() {
		return consumerNum;
	}
	public void setConsumerNum(int consumerNum) {
		this.consumerNum = consumerNum;
	}
	public double getCurrReadings() {
		return currReadings;
	}
	public void setCurrReadings(double currentMonth) {
		this.currReadings = currentMonth;
	}
	public double getUnitsConsumed() {
		return unitsConsumed;
	}
	public void setUnitsConsumed(double unitsConsumed2) {
		this.unitsConsumed = unitsConsumed2;
	}
	public double getNetAmount() {
		return netAmount;
	}
	public void setNetAmount(double netAmount2) {
		this.netAmount = netAmount2;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	
	
}
