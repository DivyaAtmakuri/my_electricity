package com.bill.bean;

public class ConsumerBean {
	private int consumerNum;
	private String conumserName;
	private String Address;
	public int getConsumerNum() {
		return consumerNum;
	}
	public void setConsumerNum(int consumerNum) {
		this.consumerNum = consumerNum;
	}
	public String getConumserName() {
		return conumserName;
	}
	public void setConumserName(String conumserName) {
		this.conumserName = conumserName;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		Address = address;
	}
	
	
}
